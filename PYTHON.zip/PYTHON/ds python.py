import os
import maskpass
import re
import random
import string
from hashlib import sha256
import bcrypt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric import padding
from Crypto.Cipher import PKCS1_OAEP

def validate_email(email):
    regex = re.compile(r'([A-Za-z0-9]+[.-_])*[A-Za-z0-9]+@[A-Za-z0-9-]+(\.[A-Z|a-z]{2,})+')
    return re.fullmatch(regex, email)

def register_user():
    while True:
        email = input("Entrer ton email: ")
        if not validate_email(email):
            print("email format Invalid")
            continue
        
        password = input("Entrer ton password : 8 characters, 1 majuscule , 1 miniscule , 1 nombre , 1 charactére special): ")
        if len(password) != 8 or not any(c.isupper() for c in password) or not any(c.islower() for c in password) \
            or not any(c.isdigit() for c in password) or not any(c in string.punctuation for c in password):
            print("password Invalid ")
            continue
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        with open("C:\Users\Shayma\Desktop\SSIR\PYTHON\ENREGISTREMENT", 'a') 
         as file:
            file.write(f"{email}:{hashed_password}\n")
        print("compte cree")
        break
def authenticate_user():
    email = input("Entrer ton email: ")
    password = maskpass.askpass(prompt="Entrer ton password: ")
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
def search_user(email, password):
            with open("C:\Users\Shayma\Desktop\SSIR\PYTHON\ENREGISTREMENT", "r") as file:
                lines = file.readlines()
            for line in lines:
                stored_email, stored_password = line.strip().split(":")
                if email == stored_email and password == stored_password:
                    return True
if search_user(email, password):
            while True:
                print("A- Donnez un mot à haché (en mode invisible)")
                print("    a- Haché le mot par SHA-256")
                print("    b- Haché le mot en générant un salt (bcrypt)")
                print("    c- Attaquer par dictionnaire le mot inséré")
                print("    d- Revenir au menu principal")

                print("B- Chiffrement (RSA)")
                print("    a- Générer les paires de clés dans un fichier")
                print("    b- Chiffrer un message de votre choix par RSA")
                print("    c- Déchiffrer le message (b)")
                print("    d- Signer un message de votre choix par RSA")
                print("    e- Vérifier la signature du message (d)")
                print("    f- Revenir au menu principal")
                
                print("C- Certificat (RSA)")
                print("    a- Générer les paires de clés dans un fichier")
                print("    b- Générer un certificat autosigné par RSA")
                print("    c- Chiffrer un message de votre choix par ce certificat")
                print("    d- Revenir au menu principal")
                choix = input("Enter ton choix: ")
                if choix == "A":     
                    submenu_choix = input("donner ton choix: ")

                    if submenu_choix == "a":
                        input_string = input("Entrer le texte hasher: ")
                        hashed = sha256(input_string.encode()).hexdigest()
                        print("   \n")
                        print("SHA-256 Hash:", hashed)
                    elif submenu_choix == "b":
                        salt = bcrypt.gensalt()
        
                        hashed = bcrypt.hashpw(input_string.encode(), salt)
                        print("   \n")
                        print("Bcrypt Hash:", hashed)
                    elif submenu_choix == "c":
                        def dictionary_attack(hashed_password, dictionary_file):
                            with open(dictionary_file, 'r', encoding='utf-8') as file:
                                for line in file:
                                    common_password = line.strip()
                                    hashed_common_password = bcrypt.hashpw(common_password.encode(), hashed_password)
                                    if hashed_common_password == hashed_password:
                                        print(f"Password found in dictionary: {common_password}")
                                        return
                            print("Password est introuvable dans le dectionnaire.")
                        input_string = input("Entrer le text à hasher: ")
                        hashed_password = bcrypt.hashpw(input_string.encode(), bcrypt.gensalt())
                        dictionary_file = "C:\Users\Shayma\Desktop\SSIR\PYTHON/dictionary.txt"  
                        dictionary_attack(hashed_password, dictionary_file)
                    elif submenu_choix == "d":
                        break
                    else:
                        print("choix invalid")
                elif choix == "B":
                   def generate_rsa_key_pair(filename):
                    private_key = rsa.generate_private_key(
                        public_exponent=65537,
                        key_size=2048
                    )
                    with open(f'{filename}_private.pem', 'wb') as private_key_file:
                        private_key_file.write(
                            private_key.private_bytes(
                                encoding=serialization.Encoding.PEM,
                                format=serialization.PrivateFormat.PKCS8,
                                encryption_algorithm=serialization.NoEncryption()
                            )
                        )
                    public_key = private_key.public_key()
                    with open(f'{filename}_public.pem', 'wb') as public_key_file:
                        public_key_file.write(
                            public_key.public_bytes(
                                encoding=serialization.Encoding.PEM,
                                format=serialization.PublicFormat.SubjectPublicKeyInfo
                            )
                        )
                def encrypt_message(public_key_file, plaintext):
                        with open(public_key_file, 'rb') as key_file:
                            public_key = serialization.load_pem_public_key(key_file.read())

                        ciphertext = public_key.encrypt(
                            plaintext.encode(),
                            padding.OAEP(
                                mgf=padding.MGF1(algorithm=padding.SHA256()),
                                algorithm=padding.SHA256(),
                                label=None
                            )
                        )
                        return ciphertext
                def decrypt_message(private_key_file, ciphertext):
                    with open(private_key_file, 'rb') as key_file:
                        private_key = serialization.load_pem_private_key(key_file.read(), password=None)

                    plaintext = private_key.decrypt(
                        ciphertext,
                        padding.OAEP(
                            mgf=padding.MGF1(algorithm=padding.SHA256()),
                            algorithm=padding.SHA256(),
                            label=None
                        )
                    )
                    return plaintext.decode()
                def sign_message(private_key_file, message):
                    with open(private_key_file, 'rb') as key_file:
                        private_key = serialization.load_pem_private_key(key_file.read(), password=None)
                    signature = private_key.sign(
                        message.encode(),
                        padding.PKCS1v15(),
                        padding.SHA256()
                    )
                    return signature
                def verify_signature(public_key_file, message, signature):
                    with open(public_key_file, 'rb') as key_file:
                        public_key = serialization.load_pem_public_key(key_file.read())
                    try:
                        public_key.verify(
                            signature,
                            message.encode(),
                            padding.PKCS1v15(),
                            padding.SHA256()
                        )
                        return True
                    except Exception as e:
                        return False
                while True:
                    print("B- Chiffrement (RSA)")
                    print("a- Générer les paires de clés dans un fichier")
                    print("b- Chiffrer un message de votre choix par RSA")
                    print("c- Déchiffrer le message (b)")
                    print("d- Signer un message de votre choix par RSA")
                    print("e- Vérifier la signature du message")
                    print("f- Revenir au menu principal")
                    choix = input("entrer ton choix: ")
                    if choix == "a":
                        filename = input("Entrer le base filename pour le key pair: ")
                        generate_rsa_key_pair(filename)
                        print("RSA key pair est générer")
                    elif choix == "b":
                        def encrypt_message(public_key_file, plaintext):
                            with open(public_key_file, 'rb') as key_file:
                                public_key = RSA.import_key(key_file.read())

                            cipher = PKCS1_OAEP.new(public_key)
                            ciphertext = cipher.encrypt(plaintext.encode())
                            return ciphertext
                            public_key_file = "file1_public.pem"

                            plaintext = input("Entrer le message à crypter: ")
                            ciphertext = encrypt_message(public_key_file, plaintext)
                            print("message cripté:", ciphertext.hex())
                    elif choix == "c":
                        private_key_file = input("Entrer ton fichier du clé privé: ")
                        ciphertext = input("Enter the ciphertext to decrypt (in hex format): ")
                        plaintext = decrypt_message(private_key_file, bytes.fromhex(ciphertext))
                        print("Decrypted message:", plaintext)
                    elif choix == "d":
                        private_key_file = input("Entrer le fichier du clé privé: ")
                        message = input("Entrer le message à signer: ")
                        signature = sign_message(private_key_file, message)
                        print("Message signed. Signature:", signature.hex())
                    elif choix == "e":
                        public_key_file = input("entrer le clé public utilisé pour le signature :")
                        message = input("entrer le message a vérifier: ")
                        signature = input("Entrer la signature à vérifier (format hexadécimale): ")
                        if verify_signature(public_key_file, message, bytes.fromhex(signature)):
                            print("Signature est valid")
                        else:
                            print("Signature est invalid")
                    elif choix == "f":
                        break
                    else:
                        print("choix est invalid")
                        
while True:
    print("1- Register")
    print("2- Authenticate")
    choix = input('donner ton choix: ')
    if choix == "1":
        register_user()
    elif choix == "2":
        authenticate_user()
    else:
        print("choix invalid")